import './App.css';
import VotreHotel from './COMPONENTS/VotreHotel';

function App() {
  return (
    <div >
      <VotreHotel/>
   
    </div>
  );
}

export default App;
